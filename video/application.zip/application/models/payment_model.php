<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Banner_model extends CI_Model {
    
    function __construct(){
        parent::__construct();      
    }
    
    function paypal_ipn(){
function FetchOrder()
   {
   $transactionID=$_POST["txn_id"];
   $item=$_POST["item_name"];
   $amount=$_POST["mc_gross"];
   $currency=$_POST["mc_currency"];
   $datefields=explode(" ",$_POST["payment_date"]);
   $time=$datefields[0];
   $date=str_replace(",","",$datefields[2])." ".$datefields[1]." ".$datefields[3];
   $timestamp=strtotime($date." ".$time);
   $status=$_POST["payment_status"];
   $firstname=$_POST["first_name"];
   $lastname=$_POST["last_name"];
   $email=$_POST["payer_email"];
   $custom=$_POST["custom"];
   if ($transactionID AND $amount)
      {
      // query to save data
	  return mysql_query("INSERT INTO tbl_transaction SET txn_id='".$transactionID."', item_name='".$item."', amount='".$amount."', currency='".$currency."', date='".$date."', status='".$payment_status."', first_name='".$firstname."', last_name='".$lastname."', payer_email='".$email."',custom='".$custom."'");
      //return $this->insertID;
      }
   else
      {
      return 0;
      }
   }
   
$url = 'https://sandbox.paypal.com/cgi-bin/webscr';
$postdata = '';
foreach($_POST as $i => $v) {
	$postdata .= $i.'='.urlencode($v).'&';
}
$postdata .= 'cmd=_notify-validate';

$web = parse_url($url);
if ($web['scheme'] == 'https') { 
	$web['port'] = 443;  
	$ssl = 'ssl://'; 
} else { 
	$web['port'] = 80;
	$ssl = ''; 
}
$fp = fsockopen($ssl.$web['host'], $web['port'], $errnum, $errstr, 30);

if (!$fp) { 
	echo $errnum.': '.$errstr;
} else {
	fputs($fp, "POST ".$web['path']." HTTP/1.1\r\n");
	fputs($fp, "Host: ".$web['host']."\r\n");
	fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
	fputs($fp, "Content-length: ".strlen($postdata)."\r\n");
	fputs($fp, "Connection: close\r\n\r\n");
	fputs($fp, $postdata . "\r\n\r\n");

	while(!feof($fp)) { 
		$info[] = @fgets($fp, 1024); 
	}
	fclose($fp);
	$info = implode(',', $info);

	if (eregi('VERIFIED', $info)) { 
		// yes valid, f.e. change payment status 
		FetchOrder();
			return 1;
	} else {
		// invalid, log error or something
			return 0;
	}
}
        
    }
}

