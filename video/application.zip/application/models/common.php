<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common extends CI_Model{
    function __construct(){
        parent::__construct();
    }

    function setMsg($item, $value){
        $this->session->set_userdata($item,$value);	
    }
    
    function getMsg($item){
        if($this->session->userdata($item) !=''){
		  $val = $this->session->userdata($item);
		  $this->session->unset_userdata($item);
		  return $val;
        }
    }

    function generateUrl($string){
        $string = strtolower($string);
        $string = preg_replace("/[^a-z0-9\s-]/", "", $string);
        $string = trim(preg_replace("/[\s-]+/", " ", $string));
        $string = preg_replace("/\s/", "-", $string);
        return $string;
    }
    

    /**
     * Gets array of data of table by id of table
     *
     * @access	public
     * @param	string	table name
     * @param   ID of the table
     * @return	array
     */
     
    function getRowById($table, $idField, $id){
        $query = $this->db->query("SELECT * FROM $table WHERE $idField='$id'")->row_array();
        return $query;
    }
    
    function getArrayById($table, $idField, $id){
        $query = $this->db->query("SELECT * FROM $table WHERE $idField='$id'")->result_array();
        return $query;        
    }
}

