<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {
    
    function __construct(){
        parent::__construct();
    }

    function checkAdmin($username, $password){
        $query = $this->db->get("tbl_admin");
        $res = $query->row_array();
        
        if($username == $res['username'] && md5($password) == $res['password']){
            $this->session->set_userdata('admin_id',$res['admin_id']);
            return TRUE;
        }
            return FALSE;
    }
    
    function login_user($username, $password){
        $userArr = $this->db->get("tbl_user")->result_array();

        foreach($userArr as $user){
            if($user['email'] == $username && $user['password'] == md5($password)){
                $this->session->set_userdata('user_id',$user['user_id']);
                $this->session->set_userdata('email',$user['email']);
                $this->session->set_userdata('fullname',ucwords($user['fullname']));

                return TRUE;
            }
        }
        $this->common->setMsg('home','Incorrect username and password');
	return FALSE;             
    }

    function register_user(){
        $fullname = $this->input->post('fullname');
        $email = $this->input->post('email');
        $gender = $this->input->post('for_gender');
        $phone = $this->input->post('phone');
        $dob = $this->input->post('dob');
        $password = $this->input->post('password');
        $confirm = $this->input->post('confirmpassword');
        
        if($password!='' && $password!=$confirm){
            $this->common->setMsg('sign_up','Password did not match');
            return FALSE;
        }
        elseif(!$fullname || !$email || !$phone){
            $this->common->setMsg('sign_up','Missing some values');
            return FALSE;
        }
        $arr = array(
                    'fullname' => $fullname,
                    'email'=>$email,
                    'gender'=>$gender,
                    'dob'=>$dob,
                    'phone'=>$phone,
                    'password'=>md5($password)
                    );
        return $this->db->insert('tbl_user',$arr);
    }
    
    function change_password($user_id){
        $oldpass = $this->input->post('old_password');
        $pass = $this->input->post('password');
        $confirmpass = $this->input->post('confirmpassword');
        if(!$pass && $pass!=$confirmpass){
            $this->common->setMsg('change_password','Password did not match');
            return FALSE;
        }
        $rs = $this->db->query("SELECT * FROM tbl_user WHERE user_id='".$user_id."' AND password='".md5($oldpass)."'")->row_array();

        if(empty($rs)){
            $this->common->setMsg('change_password','Incorrect old password');
            return FALSE; 
        }
        $stat = $this->db->update('tbl_user',array('password'=>md5($pass)),array('user_id'=>$user_id));
        if(!empty($stat)){
            $this->common->setMsg('change_password','Password changed successfully');
        } 
    }
    
    function edit_profile($user_id){
        $fullname = $this->input->post('fullname');
        $email = $this->input->post('email');
        $gender = $this->input->post('for_gender');
        $phone = $this->input->post('phone');
        $dob = $this->input->post('dob');
        
        if(!$fullname || !$email || !$phone){
            $this->common->setMsg('edit_profile','Missing some values');
            return FALSE;
        }
        $arr = array(
                    'fullname' => $fullname,
                    'email'=>$email,
                    'gender'=>$gender,
                    'dob'=>$dob,
                    'phone'=>$phone
                    );
        $stat = $this->db->update('tbl_user',$arr,array('user_id'=>$user_id));
        if(!empty($stat)){
            $this->common->setMsg('edit_profile','Edited successfully');
            return TRUE;
        }
    }
}

