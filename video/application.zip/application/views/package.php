<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo SITE_NAME;?> | Packages</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/import.css" /> 
</head>
<body>
<div class="wrapper">    
<?php $this->load->view('boxes/header');?>
	<div class="container">
    	<div class="left_part">
         <?php $this->load->view('boxes/slider'); ?>
         <div class="clearboth">
            <form name="package_form" method="post" >
<?php
if(!empty($packageArr)){
    foreach($packageArr as $package){
        ?>
    <h2 class="clearboth"><input type="radio" name="package_name" value="<?php echo $package['package_id'];?>"/><?php echo $package['package_name'];?></h2>
    <ul class="package_list">
    <li>This package cost <?php echo '$'.$package['price'];?></li>
    <li><?php echo $package['subscription_period'].' months';?></li>
    <li><?php echo $package['package_description'];?></li>
    </ul>
    <?php
    }
}else{
    echo "No package found...";
}
if(!empty($channelArr)){
    foreach($channelArr as $channel){
        ?>
        <ul class="package_channel">
        <li><img src="<?php echo base_url();?>images/channel/thumb/<?php echo $channel['image'];?>" alt="<?php echo htmlentities($channel['name']);?>" title="<?php echo htmlentities($channel['name']);?>"/></li>
        </ul>
    <?php
    }
}else{
    echo "No channel found...";
}
?>
    <input type="submit" name="submit" class="check_btn" value="Checkout" />    
            </form>
            </div>
        </div>
        <?php $this->load->view('boxes/right_part'); ?>
        </div>
<?php $this->load->view('boxes/footer');?>   
</div> 
</body>
</html>
