<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo SITE_NAME;?> | Devices</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/import.css" /> 
</head>
<body>
<div class="wrapper">    
<?php $this->load->view('boxes/header');?>
	<div class="container">
    	<div class="left_part"> 
           <?php $this->load->view('boxes/slider'); ?>
        <div class="device_list">  
        <h1>Device List</h1> 
        <div class="device_content">
<?php
if(!empty($deviceArr)){
    foreach($deviceArr as $device){
        ?>
        <div class="device_detail">
            <img src="<?php echo base_url();?>images/device/thumb/<?php echo $device['image'];?>"/>
    <h2><?php echo $device['name'];?></h2>
    <p><?php echo $device['description'];?></p>
    </div>
    <?php
    }
}
?></div>
</div>
        </div>
         <?php $this->load->view('boxes/right_part'); ?>
        </div>
<?php $this->load->view('boxes/footer');?>
</div>
</body>
</html>
