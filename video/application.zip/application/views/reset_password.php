<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home Live TV</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/import.css" /> 
</head>

<body>
	<div class="wrapper">
    	
        <?php $this->load->view('boxes/header'); ?>
   
	<div class="container">
    	<div class="left_part">
         <?php $this->load->view('boxes/slider'); ?>
         <div class="head_title">
            	<h1>Forget Password</h1>
                <div class="device_content">
                                      
                    <form name="chng_password" id="chng_password" method="post">
                <ul class="inputfield">
                    <li>
                    	<label>Enter New  Password: </label>
                        <input type="password" name="" id="">
                    </li>                    
                    <li>
                    	<label>Confirm Password: </label>
                        <input type="password" name="" id="">
                    </li>
                                         <li>
                    	<label>&nbsp;</label>
                        <input type="submit" name="change" value="Change" class="log_btn">
                    </li>
             </ul>
                    </form>
                    </div>
            </div>
         </div>
    <?php $this->load->view('boxes/right_part'); ?>
    </div>
    
     <?php $this->load->view('boxes/footer'); ?>
     </div>

</body>
</html>
