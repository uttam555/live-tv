<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home Live TV My account</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/import.css" /> 
</head>

<body>
<div class="wrapper">
    	
        <?php $this->load->view('boxes/header'); ?>
   <div class="container">
    	<div class="left_part">
			
            <div class="head_title">
            	<h1><?php echo ucwords($userRow['fullname']);?>'s Profile</h1>
                <div class="device_content">
                   
                <ul class="inputfield">
                	<li>
                    	<label>Full name:</label>
                       <label><?php echo $userRow['fullname'];?></label>

                    </li>
                    <li>
                    	<label>Email ID: </label>
                        <label><?php echo $userRow['email'];?></label>
                    </li>
                     
                
                <li>
                    	<label>Gender: </label>
                        <label><?php echo $userRow['gender']==0?'Male':'Female';?></label>
                    </li>
                    <li>
                    	<label>Phone no.: <span class="red">*</span></label>
                        <label><?php echo $userRow['phone'];?></label>
                    </li>
                     <li>
                    	<label>Date of Birth:</label>
                        <label><?php echo $userRow['dob'];?></label>
                    </li>
                   
             </ul>
                 
                    </div>
            </div>
       </div>
        <?php $this->load->view('boxes/right_log'); ?>
            </div>
       

 		<?php $this->load->view('boxes/footer'); ?>
</div>
</body>
</html>
