<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Transaction</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/import.css" />
</head>

<body>

<div class="wrapper">
    	
        <?php $this->load->view('boxes/header'); ?>
   <div class="container">
    	<div class="left_part">
        	<ul class="tranc_head tranc_title">
            	<li class="ten">ID</li>
                <li class="twentyfive">Package Name</li>
                <li class="twenty">Price</li>
                <li class="twenty">Time Period</li>
                <li class="twentyfive">Download</li>
            </ul>
            <div class="tranc_detail">
            <ul class="tranc_head">
            	<li class="ten">01</li>
                <li class="twentyfive">Service Plan 1</li>
                <li class="twenty">$100</li>
                <li class="twenty">3 Months</li>
                <li class="twentyfive"><a href="#">Download</a></li>
            </ul>
            <ul class="tranc_head ">
            	<li class="ten">01</li>
                <li class="twentyfive">Service Plan 1</li>
                <li class="twenty">$100</li>
                <li class="twenty">3 Months</li>
                <li class="twentyfive"><a href="#">Download</a></li>
            </ul>
            <ul class="tranc_head ">
            	<li class="ten">01</li>
                <li class="twentyfive">Service Plan 1</li>
                <li class="twenty">$100</li>
                <li class="twenty">3 Months</li>
                <li class="twentyfive"><a href="#">Download</a></li>
            </ul>
            </div>
        
</div>
         <?php $this->load->view('boxes/right_log'); ?>
            </div>
       

 		<?php $this->load->view('boxes/footer'); ?>
</div>
</body>
</html>
