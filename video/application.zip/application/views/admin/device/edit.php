<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Admin | Edit Device</title>
</head>
<body>
<?php $this->load->view('admin/boxes/top'); ?>

<?php $this->load->view('admin/boxes/header'); ?>

<div id="rightside">
    <h1>Edit Device</h1>    
    <div class="error_msg"><?php echo $this->common->getMsg('admin/device/edit');?></div> 
    <form name="add_device" id="add_device" method="post" enctype="multipart/form-data">      
        <div class="text_field"><label>Device Name:</label><input class="inputbox" type="text" name="device_name" id="device_name" value="<?php echo $deviceRow['name'];?>"/></div>
        <div class="text_field"><label>Description:</label><textarea class="inputbox" name="description" id="description"><?php echo $deviceRow['description'];?></textarea></div>
        <div class="text_field"><label>Image:</label><input class="inputbox" type="file" name="image" id="image" value=""/></div>          
        <div class="text_field"><label>&nbsp;</label><input class="inputbox" type="submit" name="submit" value="Edit Device" /></div>
    </form>
</div>
    
</body>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.validate.pack.js"></script>
<script type="text/javascript">
$('#add_device').validate({
    rules:{
        device_name:{required:true},
        description:{required:true}
    },
    messages:{
        device_name:{required:"Enter device name"},
        description:{required:"Enter description"}
    }
})    
</script>
</html>
