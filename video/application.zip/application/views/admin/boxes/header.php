<div id="leftside">

<div class="user">
<ul class="navigation">
    <li><a href="<?php echo base_url();?>admin/dashboard">Dashboard</a></li>
    <li><a href="<?php echo base_url();?>admin/list_channel">List Channel</a></li>
    <li><a href="<?php echo base_url();?>admin/channel_category">Channel Category</a></li>
    <li><a href="<?php echo base_url();?>admin/list_device">Device</a></li>
    <li><a href="<?php echo base_url();?>admin/list_package">Package</a></li>
    <li><a href="<?php echo base_url();?>admin/list_banner">Banner</a></li>    
    <li><a href="<?php echo base_url();?>admin/logout">Logout</a></li>
</ul>

</div>
</div>