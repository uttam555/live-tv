<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/import.css" />

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/admin_style.css" />

<div id="top">

 <p><span> <img src="<?php echo base_url();?>images/nepbay_logo.png" width="150" height="66" alt="nepbay"></span><span><img src="<?php echo base_url();?>images/cp_logo.png" width="174" height="28"></span>

  

  </div>