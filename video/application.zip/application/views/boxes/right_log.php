<div class="right_part">
       		
                <div class="right_title">
                    <h1>Welcome</h1>
                    
                    <ul>
                    	<li><img src="<?php echo base_url();?>images/key.png" /><a href="<?php echo base_url();?>change_password">Change Your Password</a></li>
                        <li><img src="<?php echo base_url();?>images/edit.png" /><a href="<?php echo base_url();?>edit_profile">Edit Profile</a></li>
                        <li><img src="<?php echo base_url();?>images/transaction.png" /><a href="<?php echo base_url();?>transactions">Transactions</a></li>
                        <li><img src="<?php echo base_url();?>images/logout.png" /><a href="<?php echo base_url();?>logout">Logout</a></li>
                    </ul>
                    </div>
            <div class="right_box">
            <div class="online_bg">
            <div class="online">
            <img src="<?php base_url();?>images/live_suooprt_online.gif" />
            	<h2><a href="#">Live Support</a></h2>
                <p>Live Support is Onine
Click here to contact with us</p>
          
            </div>
           </div>
            </div>    
                </div>