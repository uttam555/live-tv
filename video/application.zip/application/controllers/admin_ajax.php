<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_ajax extends CI_Controller{
    
    function __construct(){
        parent::__construct();
    }
    
    function delete_category(){
        if(!$this->_is_admin()) echo "fail";
        
        $cat_id = $this->input->post('cat_id');
        $channelArr = $this->db->query("SELECT * FROM tbl_channel WHERE cat_id='".$cat_id."'")->result_array();
        if(!empty($channelArr)){
            foreach($channelArr as $channel){
                @unlink(FCPATH.'images/channel/'.$channel['image']);
                @unlink(FCPATH.'images/channel/thumb/'.$channel['image']);
            }
        }
        $this->db->delete('tbl_channel',array('cat_id'=>$cat_id));
        $rs = $this->db->delete('tbl_channel_cat',array('category_id'=>$cat_id));
        if(!empty($rs)) echo "success";
        else echo "fail";
    }
    
    function delete_channel(){
        if(!$this->_is_admin()) echo "fail";
        
        $channel_id = $this->input->post('channel_id');
        $channelRow = $this->db->query("SELECT * FROM tbl_channel WHERE channel_id='".$channel_id."'")->row_array();
        @unlink(FCPATH.'images/channel/'.$channelRow['image']);
        @unlink(FCPATH.'images/channel/thumb/'.$channelRow['image']);
        $rs = $this->db->delete('tbl_channel',array('channel_id'=>$channel_id));
        if(!empty($rs)) echo "success";
        else echo "fail";        
    }
    
    function delete_device(){
        if(!$this->_is_admin()) echo "fail"; 
        
        $device_id = $this->input->post('device_id');
        $deviceRow = $this->db->query("SELECT * FROM tbl_device WHERE device_id='".$device_id."'")->row_array();
        @unlink(FCPATH.'images/device/'.$deviceRow['image']);
        @unlink(FCPATH.'images/device/thumb/'.$deviceRow['image']);
        $rs = $this->db->delete('tbl_device',array('device_id'=>$device_id));
        if(!empty($rs)) echo "success";
        else echo "fail";         
    }
    
    function delete_package(){
        if(!$this->_is_admin()) echo "fail";
        
        $package_id= $this->input->post('package_id');
        $rs = $this->db->delete('tbl_package',array('package_id'=>$package_id));
        if(!empty($rs)) echo "success";
        else echo "fail";           
    }
    
    function delete_banner(){
        if(!$this->_is_admin()) echo "fail"; 
        
        $banner_id = $this->input->post('banner_id');
        $bannerRow = $this->db->query("SELECT * FROM tbl_banner WHERE banner_id='".$banner_id."'")->row_array();
        @unlink(FCPATH.'images/banner/'.$bannerRow['image']);
        @unlink(FCPATH.'images/banner/thumb/'.$bannerRow['image']);
        $rs = $this->db->delete('tbl_banner',array('banner_id'=>$banner_id));
        if(!empty($rs)) echo "success";
        else echo "fail";          
    }
    
    function _is_admin(){
        if($this->session->userdata('admin_id')!='') return TRUE;
        else return FALSE; 
    }
}