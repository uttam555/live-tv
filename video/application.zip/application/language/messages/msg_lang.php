<?php

$lang['msg_success_add'] = "%s added successfully";
$lang['msg_success_edit'] = "%s edited successfully";

